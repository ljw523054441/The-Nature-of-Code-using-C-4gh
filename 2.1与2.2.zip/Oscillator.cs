﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace NOC
{
    class Oscillator
    {
        private Vector3d angle;
        private Vector3d velocity;
        private Vector3d amplitude;
        private Point3d startLocation;

        private static Random random = new Random();

        public Oscillator(Point3d startLocation)
        {
            this.angle = new Vector3d();
            this.velocity = new Vector3d(random.NextDouble(), random.NextDouble(), 0);
            this.amplitude = new Vector3d(random.Next(-50,51), random.Next(-50,51), 0);
            this.startLocation = startLocation;
        }

        public void Oscillate()
        {
            angle = angle + velocity;
        }

        public Circle Display(out Line line)
        {
            double x = this.startLocation.X + Math.Sin(angle.X) * amplitude.X;
            double y = this.startLocation.Y + Math.Sin(angle.Y) * amplitude.Y;

            Point3d point = new Point3d(x, y, 0);

            Circle circle = new Circle(point, 2);

            line =  new Line(Point3d.Origin, point);

            return circle;
        }
    }
}