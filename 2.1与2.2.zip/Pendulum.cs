﻿using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace NOC
{
    class Pendulum
    {
        Point3d location;
        Point3d origin;
        double r;
        double angle;
        double aVel;
        double aAcc;
        double damping;

        public Pendulum(Point3d origin,double r,double damping)
        {
            this.origin = origin;
            this.location = new Point3d();
            this.r = r;
            angle = Math.PI-Math.PI / 4;
            aVel = 0;
            aAcc = 0;
            this.damping = damping;
        }

        public void Update()
        {
            double gravity = 0.4;
            aAcc = (1 * gravity / r) * Math.Sin(angle);
            aVel += aAcc;
            angle += aVel;
            aVel *= damping;
        }

        public Circle Display(out Line line)
        {
            this.location.X = r * Math.Sin(angle);
            this.location.Y = r * Math.Cos(angle);
            location += origin;

            Circle circle = new Circle(location, 1);
            line = new Line(location, origin);

            return circle;
        }
    }
}
