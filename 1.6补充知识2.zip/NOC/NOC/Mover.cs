﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace NOC
{
    class Mover
    {

        private Point3d location;
        private Vector3d velocity;
        private Vector3d acceleration;
        private Rectangle3d boundary;

        private double a0;
        private double b0;
        private double a1;
        private double b1;

        public Mover(Point3d loc, Rectangle3d boundary)
        {
            this.location = loc;
            this.velocity = new Vector3d(0, 0, 0);
            this.acceleration = new Vector3d(0, 0, 0);
            this.boundary = boundary;

            this.a0 = boundary.Plane.OriginX;
            this.b0 = boundary.Plane.OriginX + boundary.Width;
            this.a1 = boundary.Plane.OriginY;
            this.b1 = boundary.Plane.OriginY + boundary.Height;
        }

        public void ApplyForce(Vector3d force)
        {
            this.acceleration = force;
        }

        public void Update()
        {
            this.velocity += this.acceleration;
            this.location += this.velocity;
        }

        public void Edges()
        {

            if (this.location.X > b0)
            {
                this.location.X = this.location.X - this.velocity.X;
                this.velocity.X = -this.velocity.X;
            }
            if (this.location.X < a0)
            {
                this.location.X = this.location.X - this.velocity.X;
                this.velocity.X = -this.velocity.X;
            }

            if (this.location.Y > b1)
            {
                this.location.Y = this.location.Y - this.velocity.Y;
                this.velocity.Y = -this.velocity.Y;
            }
            if (this.location.Y <= a1)
            {
                this.location.Y = this.location.Y - this.velocity.Y;
                this.velocity.Y = -this.velocity.Y;
            }
        }

        public Circle Display()
        {
            Circle circle = new Circle(this.location, 0.5);
            return circle;
        }
    }
}