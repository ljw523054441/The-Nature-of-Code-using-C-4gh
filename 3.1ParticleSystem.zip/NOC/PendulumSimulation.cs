﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Grasshopper.Kernel;
using Rhino.Geometry;

namespace NOC
{
    public class PendulumSimulation : GH_Component
    {
        Pendulum p;
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public PendulumSimulation()
          : base("PendulumSimulation", "PS",
              "doing pendulum simulation",
              "NOC", "utility")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddNumberParameter("radius", "r", "", GH_ParamAccess.item);
            pManager.AddBooleanParameter("reset", "reset", "", GH_ParamAccess.item);
            pManager.AddNumberParameter("damping", "d", "", GH_ParamAccess.item);
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddCircleParameter("ball", "B", "", GH_ParamAccess.item);
            pManager.AddLineParameter("line", "L", "", GH_ParamAccess.item);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            double radius = 1;
            bool reset = false;
            double damping = 0.9;
            DA.GetData(0, ref radius);
            DA.GetData(1, ref reset);
            DA.GetData(2, ref damping);

            if (damping>1)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "must < 1");
            }

            if (reset)
            {
                p = new Pendulum(Point3d.Origin, radius,damping);
            }
            
            p.Update();

            Circle circle = p.Display(out Line line);

            DA.SetData("ball", circle);
            DA.SetData("line", line);

            

        }

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("3e324a78-4090-4fb9-8910-8d8d3dbd44fc"); }
        }
    }
}