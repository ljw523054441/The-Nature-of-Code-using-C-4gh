﻿using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace NOC
{
    public class Particle
    {
        Point3d location;
        Vector3d velocity;
        Vector3d acceleration;
        int lifespan;
        public static Random random = new Random();

        public Particle(Point3d loc)
        {
            this.location = loc;
            this.velocity = new Vector3d(0,0,2);
            this.acceleration = new Vector3d(random.NextDouble() * 2 - 1, random.NextDouble() * 2 - 1, -random.NextDouble());
            lifespan = 255;
        }


        public void Update()
        {
            velocity += acceleration;
            location += velocity;
            lifespan -= 20;
        }

        public Mesh Display()
        {
            Sphere sphere = new Sphere(location, 5);
            Mesh sphereMesh = Mesh.CreateFromSphere(sphere, 10, 10);
            //sphereMesh.VertexColors.Add(lifespan, lifespan, lifespan);
            return sphereMesh;
        }

        public bool IsDead()
        {
            if(lifespan<0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
