﻿using System;
using System.Collections.Generic;
using System.Windows.Forms.VisualStyles;
using Grasshopper.Kernel;
using Rhino.Geometry;

namespace NOC
{
    public class SimpleHarmonicMotion : GH_Component
    {

        private int frameCount = 0;
        
        /// <summary>
        /// Initializes a new instance of the SimpleHarmonicMotion class.
        /// </summary>
        public SimpleHarmonicMotion()
          : base("SimpleHarmonicMotion", "SHM",
              "doing simple harmonic motion",
              "NOC", "utility")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddPointParameter("startLocation", "SL", "the start point", GH_ParamAccess.item);
            pManager.AddNumberParameter("amplitude", "A", "the amplitude of the simple harmonic motion",GH_ParamAccess.item);
            pManager.AddNumberParameter("period", "P", "the period of the simple harmonic motion",GH_ParamAccess.item);
            pManager.AddBooleanParameter("restart", "R", "", GH_ParamAccess.item);
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddCircleParameter("circle", "C", "the result", GH_ParamAccess.item);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            Point3d startLocation = Point3d.Origin;
            double amplitude = 0;
            double period = 0;
            bool restart = false;

            DA.GetData(0, ref startLocation);
            DA.GetData(1, ref amplitude);
            DA.GetData(2, ref period);
            DA.GetData(3, ref restart);

            Circle circle = new Circle();
            if(restart)
            {
                double x = amplitude * Math.Sin((frameCount / period) * 2 * Math.PI);

                startLocation.X = startLocation.X + x;

                circle = new Circle(startLocation, 5);

                frameCount++;

                
            }
            else
            {
                frameCount = 0;
            }

            DA.SetData(0, circle);



        }

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("db9f80c9-91f0-40be-88cd-69b072e049a0"); }
        }
    }
}