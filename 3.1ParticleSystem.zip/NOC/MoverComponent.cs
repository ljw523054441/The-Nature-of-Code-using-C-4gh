﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using NOC;
using NOC.Properties;
using Rhino.Geometry;

namespace NOC
{
    public class MoverComponent : GH_Component
    {
        private Mover mov;

        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public MoverComponent()
          : base("MoverComponent", "MComponent",
              "Mover Component",
              "NOC", "utility")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddRectangleParameter("Boundary", "boundary", "move boundary", GH_ParamAccess.item);
            pManager.AddPointParameter("Start Location", "startLocation", "the initial location of the point", GH_ParamAccess.item);
            pManager.AddVectorParameter("Force", "force", "the force vector", GH_ParamAccess.item);
            pManager.AddBooleanParameter("Reset", "reset", "reset botton", GH_ParamAccess.item);
            pManager.AddBooleanParameter("Run", "run", "run botton", GH_ParamAccess.item);
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddCircleParameter("A", "mover circle", "the circle that represent the Mover", GH_ParamAccess.item);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            Rectangle3d boundary = Rectangle3d.Unset;
            Point3d startLocation = Point3d.Origin;
            Vector3d force = Vector3d.Unset;
            bool reset = false;
            bool run = false;

            DA.GetData("Boundary", ref boundary);
            DA.GetData("Start Location", ref startLocation);
            DA.GetData("Force", ref force);
            DA.GetData("Reset", ref reset);
            DA.GetData("Run", ref run);


            if(reset)
            {
                mov = new Mover(startLocation, boundary);
            }

            if(run)
            {
                mov.ApplyForce(force);
                mov.Update();
                mov.Edges();
            }

            Circle circle = mov.Display();

            DA.SetData("A", circle);

        }

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return Properties.Resources.icon;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("31f76416-50cb-49d9-8a2d-fa408172ae70"); }
        }
    }
}