﻿using System;
using System.Collections.Generic;
using System.Data;
using Grasshopper.Kernel;
using Rhino.Geometry;

namespace NOC
{
    public class ParticleSystem : GH_Component
    {
        
        public List<Particle> p;
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public ParticleSystem()
          : base("ParticleSystem-single", "PS-single",
              "establish a particle system",
              "NOC", "ParticleSystem")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddPointParameter("startLocation", "SL", "start location", GH_ParamAccess.item);
            pManager.AddBooleanParameter("reset", "R", "reset", GH_ParamAccess.item);
            pManager.AddIntegerParameter("particleNumber", "PN", "the number of particle", GH_ParamAccess.item);
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddMeshParameter("outputMesh", "OM", "output mesh sphere", GH_ParamAccess.list);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            Point3d startLocation = Point3d.Unset;
            bool reset = false;
            int total = 10;
            DA.GetData(0, ref startLocation);
            DA.GetData(1, ref reset);
            DA.GetData(2, ref total);

            if(reset)
            {
                p = new List<Particle>();
                for(int i = 0;i<=total;i++)
                {
                    Particle particle = new Particle(startLocation);
                    p.Add(particle);
                }
            }

            List<Mesh> meshes = new List<Mesh>();

            for (int i = 0; i <=total; i++)
            {
                p[i].Update();
                if (p[i].IsDead())
                {
                    p.Remove(p[i]);
                    Particle particle = new Particle(startLocation);
                    p.Add(particle);
                }
            }

            foreach (var item in p)
            {
                Mesh mesh = item.Display();
                meshes.Add(mesh);
            }
            


            DA.SetDataList(0, meshes);

        }

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("f1b2a59f-1ade-4d42-ae91-80d7ef46cd4a"); }
        }
    }
}